<template>
    <div class="iq-team text-center mb-5">
  <div class="iq-provider-img position-relative">
    <div class="placeholder-glow">
      <span
        class="placeholder col-12 provider-img img-fluid object-cover rounded-3 w-100"
      ></span>
      <div>
        <h5 class="placeholder col-7 provider-heading mt-3"></h5>
      </div>
      <h6 class="placeholder col-3 mt-3"></h6>
    </div>
  </div>
</div>
</template>
