<template>
    <div class="service-box-card {{class-name}} rounded-3 mb-5">
  <div class="iq-image position-relative">
    <p class="placeholder-glow">
      <span class="placeholder col-12 service-img rounded-3"></span>
    </p>
  </div>
  <div
    class="placeholder-glow d-flex align-items-start align-items-md-center justify-content-between mt-4 flex-column flex-sm-row flex-sm-wrap gap-2"
  >
    <span class="placeholder col-5 rounded-2"></span>
    <span class="placeholder col-5 rounded-2"></span>
  </div>
  <a class="service-heading mt-2">
    <h5 class="placeholder-glow">
      <span class="placeholder col-9 rounded-2"></span>
    </h5>
  </a>
  <li class="list-inline p-0 m-0 price-content placeholder-glow">
    <span class="placeholder col-9 rounded-2"></span>
  </li>
</div>
</template>
