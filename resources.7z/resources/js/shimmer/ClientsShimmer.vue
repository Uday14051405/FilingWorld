<template>
    <div class="iq-testimonial testimonial position-relative bg-body rounded-5">
  <div class="quote text-center rounded-circle">
    <img
      src="landing-images/testimonial/quote.svg"
      class="img-fluid"
      alt="quote"
    />
  </div>
  <div class="placeholder-glow">
    <h5 class="about-review-title line-count-1 placeholder col-6"></h5>
    <p class="mt-4 mb-0 testimonial-content placeholder col-11"></p>
    <p class="mt-3 mb-0 testimonial-content placeholder col-10"></p>
    <p class="mt-3 mb-3 testimonial-content placeholder col-11"></p>
  </div>
  <div
    class="row align-items-center justify-content-between mt-4 ms-1 placeholder-glow"
  >
    <div class="placeholder col-sm-3"></div>
    <div class="col-sm-7 mt-sm-0 mt-3">
      <div
        class="d-flex align-items-sm-center flex-sm-row flex-column justify-content-sm-end gap-3 placeholder-glow"
      >
        <div
          class="testimonial-user-image flex-shrink-0 avatar-50 placeholder col-3"
        ></div>
        <div class="user-content placeholder-glow col-9">
          <h6 class="testimonial-user placeholder col-6"></h6>
          <span class="testimonial-user-meta placeholder col-8"></span>
        </div>
      </div>
    </div>
  </div>
</div>
</template>
