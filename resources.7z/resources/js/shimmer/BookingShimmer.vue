<template>
    <div class="placeholder-glow">
<div class="bg-gray padding-50 rounded-3 position-relative mb-5" style="--bs-bg-opacity: .1" >
   <div class="row align-items-center">
      <div class="col-lg-4">
        <span class="placeholder img-fluid rounded-3 object-cover w-100 booking-img"></span>
      </div>
      <div class="col-lg-8 mt-5 mt-lg-0">

            <span class=" placeholder w-50"></span>
         <div class="d-flex align-items-center gap-1 mt-3">
               <span class="placeholder w-25"></span>
         </div>
         <div class="booking-date position-absolute top-0 p-0">

            <span class=" placeholder" style="width: 12.5rem; height:2.5rem;"></span>
         </div>
         <div class="row mt-5">
            <div class="col-lg-6 col-md-5">
               <span class="placeholder w-25"></span>
               <div class="table-responsive">
                  <table class="w-100 table mb-0 table-border-none booking-detail-table">
                     <tbody>
                        <tr>
                           <th>
                              <span class="placeholder w-100"></span>
                           </th>
                           <td>
                              <span class="placeholder w-100"></span>
                           </td>
                        </tr>
                        <tr>
                           <th>
                              <span class="placeholder w-100"></span>
                           </th>
                           <td>
                              <span class="placeholder w-100"></span>
                           </td>
                        </tr>
                        <tr>
                           <th>
                              <span class="placeholder w-100"></span>
                           </th>
                           <td>
                              <span class="placeholder w-100"></span>
                           </td>
                        </tr>
                     </tbody>
                  </table>
               </div>
            </div>
            <div class="col-lg-2 col-md-2 position-relative d-none d-md-block">
               <div class="vr h-100 position-absolute start-50"></div>
            </div>
            <div class="col-lg-4 col-md-5 mt-5 mt-md-0">
                <span class="placeholder w-50 mb-2"></span>
               <div class="table-responsive">
                  <table class="w-100 table mb-0 table-border-none booking-detail-table">
                     <tbody>
                        <tr>
                           <th>
                              <span class="placeholder w-75"></span>
                           </th>
                           <td class="text-capitalize">
                               <span class="placeholder w-50"></span>
                           </td>
                        </tr>
                        <tr>
                           <th>
                              <span class="placeholder w-75"></span>
                           </th>
                           <td class="text-capitalize">
                              <span class="placeholder w-50"></span>
                           </td>
                        </tr>
                        <tr>
                           <th>
                              <span class="placeholder w-75"></span>
                           </th>
                           <td class="text-capitalize">
                              <span class="placeholder w-50"></span>
                           </td>
                        </tr>
                     </tbody>
                  </table>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
</div>
</template>
