<template>
<div class="container">
    <div class="card text-center bg-light rounded-3 ">
  <div class="card-body category-card">
    <div class="placeholder-glow img-bg d-inline-block rounded-3">
      <span class="placeholder col-5 avatar-70"></span>
    </div>
    <h5 class="placeholder-glow">
      <span
        class="placeholder col-6 categories-name text-capitalize mt-4 mb-2 line-count-1 rounded-2"
      ></span>
      <p
        class="placeholder col-7 mt-1 categories-desc mb-0 text-capitalize line-count-2 rounded-2"
      ></p>
    </h5>
  </div>
</div>

</div>
</template>
