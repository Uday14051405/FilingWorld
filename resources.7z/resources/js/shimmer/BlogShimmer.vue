<template>
   <div class=" iq-blog blog-standard position-relative">
  <div class="blog-image position-relative">
    <p class="placeholder-glow img-fluid  ">
      <span class="placeholder col-12 rounded-3  img-fluid w-100 blog-image rounded-3" style="height: 17.7rem;"></span>
    </p>
    <p class="placeholder-glow">
    <span class=" placeholder rounded-5  position-absolute top-0 end-0 mt-3 me-3" style="width: 3.7rem; height:1.8rem">
       </span>
    </p>
  </div>

  <div class="blog-title text-start mb-2">
    <span class="placeholder-glow">
        <span class="placeholder rounded w-75 text-capitalize line-count-2 mt-5" style="height:1.5rem"></span>
        <span class="placeholder rounded w-50 text-capitalize line-count-2 " style="height:1.5rem"></span>
        </span>
    </div>
    <div class="iq-blog-meta-bottom d-flex align-items-center justify-content-between mt-5 ">
     <div class="author-block placeholder-glow rounded d-flex align-items-center col-6 gap-2">
        <p class="img-fluid placeholder rounded-circle avatar-30 col-4"></p>
        <p class="placeholder p-1 rounded col-5" style="height:1.3rem"></p>
    </div>
    <div class="iq-btn-container col-6 placeholder-glow d-flex justify-content-end">
        <p class="placeholder col-5 rounded" style="height:1.3rem" >
        </p>
    </div>
    </div>
</div>

</template>
