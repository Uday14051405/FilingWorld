<div class="iq-popup-video">
    <div class="iq-video-icon position-absolute top-50 start-50 translate-middle">
       <div class="iq-video text-center d-inline-block iq-fslightbox-img">
          <a class="d-block position-relative" target="_blank" data-fslightbox="html5-video" href="{{ $videoLinkUrl }}"
             data-video-poster="<i aria-hidden='true' class='fas fa-play text-primary'></i>">
             <span class="text-white icon position-relative">
                <svg width="21" height="23" viewBox="0 0 21 23" fill="none" xmlns="http://www.w3.org/2000/svg">
                   <path
                      d="M6.3726 21.4399L18.4135 14.583C20.4203 13.4402 20.4374 10.5535 18.4443 9.38693L6.48559 2.38769C4.49247 1.22115 1.98395 2.64968 1.97026 4.95904L1.88809 18.8152C1.8744 21.1246 4.36579 22.5827 6.3726 21.4399Z"
                      stroke="currentColor" stroke-width="2" />
                </svg>
             </span>
          </a>
       </div>
    </div>
 </div>
