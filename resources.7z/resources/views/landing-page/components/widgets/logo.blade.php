<a href="{{route('frontend.index')}}" class="navbar-brand m-0">
    <span class="logo-normal">
      <img src="{{ getSingleMedia(imageSession('get'),'footer_logo',null) }}" class="img-fluid" alt="logo" loading="lazy">
    </span>
 </a>
