@component('mail::message')
    {!! $templateData ?? '' !!}
@endcomponent

